(() => {
  const rules = globalThis.BGExtensionRules;
  const themeApi = globalThis.BGMosaicThemes;
  const handoff = globalThis.BGThemeHandoff;
  if (!rules || !themeApi || !handoff) return;
  // Skip non-output pages entirely: no observers, no apply loop.
  if (!rules.isOutputPage(location.href)) return;

  const OVERLAY_ID = "dyn-mosaic-theme";
  const STYLE_ID = "dyn-mosaic-theme-style";

  let applyTimer = 0;
  let tickTimer = 0;
  let dealIndex = 0;
  let mountedTheme = "";
  let mountedAspect = "";
  let mountedEmpty = true;
  let active = null;
  const liveSet = new Set();
  const retiring = new Set();
  const incoming = [];
  const pool = [];
  let lastShown = "";

  function collectUrls() {
    const urls = [];
    const seenNow = new Set();
    rules.mosaicImages().forEach((img) => {
      const src = img.currentSrc || img.src;
      if (!src || src.startsWith("data:")) return;
      if (rules.isSkippedMosaicImage(img)) return;
      if (seenNow.has(src)) return;
      seenNow.add(src);
      urls.push(src);
    });
    return urls;
  }

  function syncFeed() {
    const now = collectUrls();
    const nowSet = new Set(now);
    const added = [];
    now.forEach((src) => {
      if (!liveSet.has(src)) {
        added.push(src);
        incoming.push(src);
      }
      retiring.delete(src);
    });
    const removed = [];
    liveSet.forEach((src) => {
      if (nowSet.has(src)) return;
      removed.push(src);
      retiring.add(src);
    });
    liveSet.clear();
    now.forEach((src) => liveSet.add(src));
    pool.length = 0;
    now.forEach((src) => pool.push(src));
    if (dealIndex >= pool.length) dealIndex = 0;
    for (let i = incoming.length - 1; i >= 0; i -= 1) {
      if (!liveSet.has(incoming[i])) incoming.splice(i, 1);
    }
    return { added, removed };
  }

  function nextUrl(avoid) {
    const blocked = visibleOverlaySrcs();
    addAvoid(blocked, avoid);
    if (lastShown) blocked.add(lastShown);

    function takeIncoming(filter) {
      for (let i = 0; i < incoming.length; i += 1) {
        const src = incoming[i];
        if (!src || !liveSet.has(src) || retiring.has(src)) continue;
        if (filter && filter.has(src)) continue;
        incoming.splice(i, 1);
        return src;
      }
      return "";
    }

    function takePool(filter) {
      if (!pool.length) return "";
      for (let step = 0; step < pool.length; step += 1) {
        const src = pool[(dealIndex + step) % pool.length];
        if (!src || retiring.has(src)) continue;
        if (filter && filter.has(src)) continue;
        dealIndex = (dealIndex + step + 1) % pool.length;
        return src;
      }
      return "";
    }

    const picked = takeIncoming(blocked) || takePool(blocked);
    if (picked) {
      lastShown = picked;
      return picked;
    }

    const soft = new Set();
    addAvoid(soft, avoid);
    if (lastShown) soft.add(lastShown);
    const fallback = takeIncoming(soft) || takePool(soft);
    if (fallback) {
      lastShown = fallback;
      return fallback;
    }
    const recycle = takePool(null);
    if (recycle) {
      lastShown = recycle;
      return recycle;
    }
    return pool[0] || "";
  }

  function visibleOverlaySrcs() {
    const blocked = new Set();
    const root = document.getElementById(OVERLAY_ID);
    if (!root) return blocked;
    root.querySelectorAll(".dyn-card img").forEach((img) => {
      const src = img.currentSrc || img.src;
      if (src) blocked.add(src);
    });
    return blocked;
  }

  function addAvoid(set, avoid) {
    if (!avoid) return;
    if (typeof avoid === "string") {
      if (avoid) set.add(avoid);
      return;
    }
    if (typeof avoid[Symbol.iterator] === "function") {
      for (const src of avoid) {
        if (src) set.add(src);
      }
    }
  }

  function makeApi() {
    return {
      nextUrl,
      isRetiring(src) {
        return Boolean(src && retiring.has(src));
      },
      hasIncoming() {
        return incoming.some((src) => liveSet.has(src));
      },
    };
  }

  function ensureStyle() {
    let style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement("style");
      style.id = STYLE_ID;
      document.documentElement.appendChild(style);
    }
    if (style.textContent !== themeApi.STYLE) {
      style.textContent = themeApi.STYLE;
    }
  }

  function ensureOverlay() {
    const host = rules.findOverlayHost();
    if (!host) return null;
    let root = document.getElementById(OVERLAY_ID);
    if (!root || root.parentElement !== host) {
      if (root) host.appendChild(root);
      else {
        root = document.createElement("div");
        root.id = OVERLAY_ID;
        host.appendChild(root);
      }
    }
    root.classList.remove("is-leaving");
    if (typeof rules.applyStageFrame === "function") rules.applyStageFrame(root);
    return root;
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function decodeUrl(src) {
    if (!src) return Promise.resolve();
    return new Promise((resolve) => {
      const img = new Image();
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        resolve();
      };
      img.onload = () => {
        if (typeof img.decode === "function") img.decode().then(done).catch(done);
        else done();
      };
      img.onerror = done;
      img.src = src;
      setTimeout(done, 1200);
    });
  }

  function decodeUrls(urls) {
    const unique = [];
    const seen = new Set();
    (urls || []).forEach((src) => {
      if (!src || seen.has(src)) return;
      seen.add(src);
      unique.push(src);
    });
    return Promise.all(unique.slice(0, 16).map(decodeUrl));
  }

  function stopTick() {
    if (tickTimer) {
      clearInterval(tickTimer);
      tickTimer = 0;
    }
  }

  function startTick(interval) {
    stopTick();
    tickTimer = setInterval(() => {
      // No point churning the DOM while the display isn't visible.
      if (document.hidden) return;
      if (!active || pool.length < 1) return;
      const root = document.getElementById(OVERLAY_ID);
      if (!root || typeof active.def.tick !== "function") return;
      active.def.tick(root, pool, active.state, makeApi());
    }, interval || 2500);
  }

  function unmountTheme() {
    stopTick();
    const root = document.getElementById(OVERLAY_ID);
    if (active && active.def && typeof active.def.unmount === "function" && root) {
      active.def.unmount(root, active.state);
    }
    if (root) root.replaceChildren();
    active = null;
    mountedTheme = "";
    mountedAspect = "";
    mountedEmpty = true;
    lastShown = "";
    // Reset feed state so retired/seen URLs can't accumulate forever on a
    // long-running display cycling through many different mosaics.
    liveSet.clear();
    retiring.clear();
    incoming.length = 0;
    dealIndex = 0;
  }

  function mountTheme(id) {
    const def = themeApi.themes[id];
    if (!def) return false;
    unmountTheme();
    const root = ensureOverlay();
    if (!root) return false;
    root.dataset.theme = id;
    if (def.engine) root.dataset.engine = def.engine;
    else delete root.dataset.engine;
    const state = def.mount(root, pool, makeApi()) || {};
    active = { id, def, state };
    mountedTheme = id;
    mountedAspect = rules.currentStageAspect ? rules.currentStageAspect() : "auto";
    mountedEmpty = pool.length === 0;
    startTick(def.interval);
    return true;
  }

  function teardownSoft() {
    unmountTheme();
    document.documentElement.classList.remove("dyn-mosaic-on");
    const root = document.getElementById(OVERLAY_ID);
    if (root) root.remove();
  }

  function teardownHard() {
    teardownSoft();
    const style = document.getElementById(STYLE_ID);
    if (style) style.remove();
    handoff.clearMode("mosaic");
  }

  handoff.register("mosaic", {
    hide() {
      stopTick();
      const root = document.getElementById(OVERLAY_ID);
      if (!root) return Promise.resolve();
      root.classList.add("is-leaving");
      return wait(420);
    },
    teardown: teardownSoft,
  });

  const customApi = globalThis.BGCustomThemes;
  if (customApi && typeof customApi.onChange === "function") {
    customApi.onChange(() => {
      mountedTheme = "";
      scheduleApply();
    });
  }

  async function apply() {
    if (customApi && typeof customApi.whenReady === "function") {
      await customApi.whenReady();
    }
    // Keep theming with cached settings even after an extension reload kills
    // the chrome APIs; only a page refresh swaps in the new script.
    const settings = await rules.loadSettings();
    handoff.applyCovers(settings);
    const theme = settings.enabled ? rules.normalizeMosaicTheme(settings.mosaicTheme) : "off";
    const aspect = rules.normalizeStageAspect
      ? rules.normalizeStageAspect(settings.stageAspect)
      : "auto";
    const def = themeApi.themes[theme];

    if (theme === "off" || !def) {
      teardownHard();
      return;
    }

    const kind = handoff.liveKind();
    if (kind !== "mosaic") return;

    await handoff.activate("mosaic", {
      prepare() {
        syncFeed();
        return decodeUrls(pool);
      },
      async reveal() {
        ensureStyle();
        document.documentElement.classList.add("dyn-mosaic-on");
        const { added, removed } = syncFeed();
        const overlay = document.getElementById(OVERLAY_ID);
        if (mountedTheme !== theme || mountedAspect !== aspect || !overlay) {
          mountTheme(theme);
        } else if (pool.length && mountedEmpty) {
          mountTheme(theme);
        }
        const live = document.getElementById(OVERLAY_ID);
        if (live && typeof rules.ensureBrandChrome === "function") {
          rules.ensureBrandChrome(live);
        }
        if (!live || !active) return;
        if (active && (added.length || removed.length) && typeof active.def.tick === "function") {
          const bursts = Math.min(Math.max(added.length, removed.length ? 1 : 0), 3);
          for (let i = 0; i < bursts; i += 1) {
            active.def.tick(live, pool, active.state, makeApi());
          }
        }
      },
    });
  }

  function scheduleApply() {
    if (applyTimer) clearTimeout(applyTimer);
    applyTimer = setTimeout(() => {
      applyTimer = 0;
      apply().catch(() => {});
    }, 50);
  }

  const observer = new MutationObserver((records) => {
    const relevant = records.some((record) => {
      const target = record.target;
      if (!target) return true;
      if (target.id === OVERLAY_ID || target.id === handoff.HOST_ID) return false;
      if (typeof target.closest === "function" && target.closest("#" + OVERLAY_ID + ", #" + handoff.HOST_ID)) {
        return false;
      }
      return true;
    });
    if (relevant) scheduleApply();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["src"],
  });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local") scheduleApply();
    });
  } catch {
    /* extension reloaded */
  }

  // Mosaic layouts are computed at mount from the canvas size. When the
  // window is resized, remount so every tile re-lays out proportionally to
  // the new canvas (stage-based themes also self-fit via ResizeObserver).
  let resizeRemountTimer = 0;
  window.addEventListener("resize", () => {
    if (resizeRemountTimer) clearTimeout(resizeRemountTimer);
    resizeRemountTimer = setTimeout(() => {
      resizeRemountTimer = 0;
      if (active && mountedTheme) mountTheme(mountedTheme);
    }, 250);
  });

  apply().catch(() => {});
})();
